=== Plugin Name ===
Donate link: https://stellarwebdev.com/
Tags: comments, spam
Requires at least: 5.8.1
Tested up to: 5.8.1
Stable tag: 5.8.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Custom Plugin specifically designed for PGH Fresh ecommerce site.

== Installation ==

1. Upload `custom-pgh-catering-plugin.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0.1 =
* Added Packing and Kitchen Reports

= 1.0.0 =
* Initial version
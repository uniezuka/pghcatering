<a href="<?= $kitchen_report_page ?>" class="button reports">Kitchen</a>
<a href="<?= $packing_report_page ?>" class="button reports">Packing</a>
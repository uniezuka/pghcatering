<?php

class Custom_Pgh_Catering_Plugin_Deactivator {
	public static function deactivate() {
	}
}
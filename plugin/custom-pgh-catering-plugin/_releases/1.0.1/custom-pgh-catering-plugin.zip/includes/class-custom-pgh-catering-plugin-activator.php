<?php

class Custom_Pgh_Catering_Plugin_Activator {
	public static function activate() {
	}
}